Posted on XXXX.

- note a bit about the history of this project

- overuse of containers

- developer experience

- what people can build on top of devenv