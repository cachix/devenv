There are a few examples [in the devenv repository](https://github.com/cachix/devenv/tree/main/examples).

[devenv project itself uses devenv that serves as an example](https://github.com/cachix/devenv/blob/main/devenv.nix).

If you're searching for an example but can't find it, [let us know](https://github.com/cachix/devenv/issues/12).