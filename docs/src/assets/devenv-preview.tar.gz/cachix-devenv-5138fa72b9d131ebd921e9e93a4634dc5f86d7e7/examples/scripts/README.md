Load the project:

```
$ devenv shell
```

Once in a shell, script `gitversion` is available in your `$PATH`:

```
$ gitversion
hello git git version 2.36.2
```