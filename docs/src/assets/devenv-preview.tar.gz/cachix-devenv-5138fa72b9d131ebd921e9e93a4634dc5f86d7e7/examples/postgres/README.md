devenv up 

starts postgresql